# Portofolio Santri

Website portofolio pribadi statis (HTML, CSS, JavaScript), responsif untuk HP dan laptop.

## Cara melihat
Buka `index.html` di browser.

## Sebelum dipublikasikan
Ganti teks contoh seperti:
- `Nama Anda`
- `Isi nama lengkap Anda`
- nama sekolah/pesantren dan universitas
- domisili
- `emailanda@example.com`

## Publikasi
Folder ini bisa diunggah ke repository GitHub dan dipublikasikan melalui GitHub Pages:
1. Masuk ke repository GitHub.
2. Unggah file `index.html`, `style.css`, `script.js`, dan `README.md` ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` atau `master`, folder `/ (root)`, lalu **Save**.
6. Tunggu alamat HTTPS GitHub Pages muncul pada halaman Pages.

Catatan: website ini belum dipublikasikan ke internet. Proses publikasi perlu dilakukan dari akun GitHub pemilik repository.

# Portofolio Santri — GitHub Pages

Website statis untuk GitHub Pages. Tidak membutuhkan Flask, Python, atau server.

## File
- `index.html` — isi website
- `style.css` — desain responsif
- `script.js` — menu HP dan tahun otomatis

## Cara memasang lewat HP
1. Buka repositori GitHub: https://github.com/absyuk20/portfolio_santri
2. Pastikan berada di branch `main` (atau branch utama yang digunakan).
3. Pilih **Add file** → **Upload files**.
4. Ekstrak ZIP ini terlebih dahulu di HP, lalu unggah `index.html`, `style.css`, dan `script.js` ke bagian paling atas/root repositori (bukan ke dalam folder lain).
5. Isi pesan commit, misalnya `Buat website portofolio GitHub Pages`, lalu tekan **Commit changes**.
6. Buka **Settings** → **Pages**.
7. Pada **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch `main` (atau branch utama repositori) dan folder `/ (root)`, lalu tekan **Save**.
9. Tunggu proses penerbitan selesai. Alamat proyek yang dituju:
   https://absyuk20.github.io/portfolio_santri/

Jika repositori menggunakan branch `master`, pilih `master` pada pengaturan Pages.

## Catatan
- Pastikan `index.html` berada di root repositori.
- Kontak email ditampilkan sebagai `abdishakur20@gmail.com`. Ubah di `index.html` jika ingin menggunakan alamat lain.
- Periksa kembali ejaan dan riwayat pendidikan sebelum dipublikasikan.
